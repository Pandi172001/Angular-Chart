// highcharts.d.ts

declare module 'highcharts' {
    const Highcharts: any;
    export = Highcharts;
  }
  